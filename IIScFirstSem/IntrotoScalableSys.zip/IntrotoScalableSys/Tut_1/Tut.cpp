#include <iostream>
using namespace std;


int main() {
    cout << "Hello, World!" << std::endl;
    return 0;
}
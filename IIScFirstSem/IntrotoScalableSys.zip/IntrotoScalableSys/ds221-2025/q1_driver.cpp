// C++98 compatible version (removed C++11 features: unordered_map, chrono, atomic, <random>, lambdas)

#include <ctime>
#include <cstdlib>
#include <map>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <csignal>
#include <cmath>
using namespace std;

// #define Q1_USE_SORT_PATH   // Uncomment to use sort-based path

static ofstream g_fout;
static bool g_open = false;

void handle_sigint(int) {
    if (g_open) {
        g_fout.flush();
        cerr << "\nSIGINT: flushed outputs_q1.csv\n";
    }
    exit(0);
}

struct Q1Entry {
    int cnt;
    int minw;
};

// Hash path replaced with std::map for C++98 (O(log N) operations)
static vector< vector<int> > question_one_hash(const vector< vector<int> >& parcels) {
    map<int, Q1Entry> mp;
    vector< vector<int> > out;

    for (size_t i = 0; i < parcels.size(); ++i) {
        if (parcels[i].size() < 2) continue;
        int id = parcels[i][0];
        int w  = parcels[i][1];
        map<int,Q1Entry>::iterator it = mp.find(id);
        if (it == mp.end()) {
            Q1Entry e; e.cnt = 1; e.minw = w;
            mp.insert(make_pair(id, e));
        } else {
            it->second.cnt += 1;
            if (w < it->second.minw) it->second.minw = w;
        }
    }

    out.reserve(mp.size());
    for (map<int,Q1Entry>::iterator it = mp.begin(); it != mp.end(); ++it) {
        if (it->second.cnt > 1) {
            vector<int> row;
            row.push_back(it->first);
            row.push_back(it->second.minw);
            out.push_back(row);
        }
    }
    // Already sorted by key because std::map is ordered
    return out;
}

// Sort-based path (also C++98)
static vector< vector<int> > question_one_sort(const vector< vector<int> >& parcels) {
    vector< pair<int,int> > a;
    a.reserve(parcels.size());
    for (size_t i = 0; i < parcels.size(); ++i) {
        if (parcels[i].size() >= 2) {
            a.push_back(pair<int,int>(parcels[i][0], parcels[i][1]));
        }
    }
    if (a.empty()) return vector< vector<int> >();

    sort(a.begin(), a.end()); // pair compares by first then second

    vector< vector<int> > out;
    int n = (int)a.size();
    int i = 0;
    while (i < n) {
        int id = a[i].first;
        int cnt = 0;
        int mn = a[i].second;
        int j = i;
        while (j < n && a[j].first == id) {
            ++cnt;
            if (a[j].second < mn) mn = a[j].second;
            ++j;
        }
        if (cnt > 1) {
            vector<int> row;
            row.push_back(id);
            row.push_back(mn);
            out.push_back(row);
        }
        i = j;
    }
    // Already in ascending id order
    return out;
}

vector< vector<int> > question_one(const vector< vector<int> >& parcels) {
#ifdef Q1_USE_SORT_PATH
    return question_one_sort(parcels);
#else
    return question_one_hash(parcels);
#endif
}

static bool check_correctness(const vector< vector<int> >& parcels,
                              const vector< vector<int> >& output) {
    map<int, vector<int> > id_weights;
    for (size_t i = 0; i < parcels.size(); ++i) {
        if (parcels[i].size() < 2) continue;
        id_weights[parcels[i][0]].push_back(parcels[i][1]);
    }

    vector< pair<int,int> > expected;
    for (map<int, vector<int> >::iterator it = id_weights.begin(); it != id_weights.end(); ++it) {
        if (it->second.size() > 1) {
            int mn = it->second[0];
            for (size_t k = 1; k < it->second.size(); ++k)
                if (it->second[k] < mn) mn = it->second[k];
            expected.push_back(pair<int,int>(it->first, mn));
        }
    }
    sort(expected.begin(), expected.end());

    vector< pair<int,int> > actual;
    for (size_t i = 0; i < output.size(); ++i) {
        if (output[i].size() == 2)
            actual.push_back(pair<int,int>(output[i][0], output[i][1]));
    }
    sort(actual.begin(), actual.end());

    if (expected.size() != actual.size()) return false;
    for (size_t i = 0; i < expected.size(); ++i) {
        if (expected[i].first != actual[i].first ||
            expected[i].second != actual[i].second)
            return false;
    }
    return true;
}

static int count_duplicates(const vector< vector<int> >& parcels) {
    map<int,int> cnt;
    for (size_t i = 0; i < parcels.size(); ++i) {
        if (parcels[i].size() < 2) continue;
        cnt[parcels[i][0]] += 1;
    }
    int d = 0;
    for (map<int,int>::iterator it = cnt.begin(); it != cnt.end(); ++it)
        if (it->second > 1) ++d;
    return d;
}

static size_t estimate_memory_usage(const vector< vector<int> >& parcels,
                                    const vector< vector<int> >& result) {
    // Rough estimate (not exact)
    size_t mem = sizeof(parcels) + parcels.capacity() * sizeof(vector<int>);
    for (size_t i = 0; i < parcels.size(); ++i)
        mem += sizeof(vector<int>) + parcels[i].capacity() * sizeof(int);

    mem += sizeof(result) + result.capacity() * sizeof(vector<int>);
    for (size_t i = 0; i < result.size(); ++i)
        mem += sizeof(vector<int>) + result[i].capacity() * sizeof(int);
    return mem;
}

int main() {
    signal(SIGINT, handle_sigint);
    srand(42); // simple RNG seed

    int min_n = 1000;
    int max_n = 100000000;   // reduced from 100M for practicality under C++98 version
    int num_tests = 20;

    g_fout.open("outputs_q1.csv", ios::out | ios::trunc);
    if (!g_fout) {
        cerr << "Cannot open outputs_q1.csv\n";
        return 1;
    }
    g_open = true;

    g_fout << "Test#,N(Packages),Time(µs approx),NumDuplicates,Memory(bytes),Correct\n";
    g_fout.flush();

    double log_min = log10((double)min_n);
    double log_max = log10((double)max_n);

    for (int t = 1; t <= num_tests; ++t) {
        double log_n = log_min + (log_max - log_min) * (double)(t - 1) / (double)(num_tests - 1);
        int n = (int)pow(10.0, log_n);

        vector< vector<int> > parcels;
        parcels.resize(n, vector<int>(2));
        for (int i = 0; i < n; ++i) {
            parcels[i][0] = rand() % 100000001;
            parcels[i][1] = rand() % 100000001;
        }

        clock_t start = clock();
        vector< vector<int> > result = question_one(parcels);
        clock_t end = clock();
        long long micros = (long long)((end - start) * 1000000.0 / CLOCKS_PER_SEC);

        bool correct = check_correctness(parcels, result);
        int num_duplicates = count_duplicates(parcels);
        size_t mem = estimate_memory_usage(parcels, result);

        g_fout << t << ',' << n << ',' << micros << ',' << num_duplicates
               << ',' << mem << ',' << (correct ? "YES" : "NO") << '\n';
        g_fout.flush();

        cout << "Test " << t << " n=" << n
#ifdef Q1_USE_SORT_PATH
             << " [SORT]"
#else
             << " [MAP]"
#endif
             << " dup=" << num_duplicates
             << " time(us)~" << micros
             << " correct=" << (correct ? "Y" : "N") << '\n';
    }

    g_fout.close();
    g_open = false;
    return 0;
}
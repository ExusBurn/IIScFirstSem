// C++98 compatible version (removed: unordered_map, chrono, <random>, atomic, digit separators, range-for, auto, lambdas)

#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <csignal>
#include <stack>
#include <ctime>
#include <cstdlib>
using namespace std;

/*
Q2 DRIVER (C++98 version)
- Uses std::map instead of unordered_map (O(log N)).
- Uses rand()/srand() instead of <random>.
- Uses clock() for timing (approx microseconds).
- Removed digit separators and C++11 syntax.
*/

static ofstream g_fout;
static bool g_open = false;

void handle_sigint(int) {
    if (g_open) {
        g_fout.flush();
        cerr << "\nSIGINT: flushed outputs_q2.csv\n";
    }
    exit(0);
}

/* ------------ Balanced full tree traversal generator ------------ */
struct BuiltTree {
    vector<int> preorder;
    vector<int> inorder;
    int total_nodes;
    BuiltTree(): total_nodes(0) {}
};

int build_balanced_rec(int L,int R,int& nextI,vector<int>& pre,vector<int>& in) {
    if (L==R) { pre.push_back(L); in.push_back(L); return L; }
    int mid=(L+R)/2;
    int myId=nextI++;
    pre.push_back(myId);
    build_balanced_rec(L,mid,nextI,pre,in);
    in.push_back(myId);
    build_balanced_rec(mid+1,R,nextI,pre,in);
    return myId;
}

BuiltTree build_balanced_full_tree(int n) {
    BuiltTree bt;
    if (n<=0) return bt;
    if (n==1) {
        bt.preorder.push_back(1);
        bt.inorder.push_back(1);
        bt.total_nodes=1;
        return bt;
    }
    bt.preorder.reserve(2*n-1);
    bt.inorder.reserve(2*n-1);
    int nextI = n+1;
    build_balanced_rec(1,n,nextI,bt.preorder,bt.inorder);
    bt.total_nodes = 2*n - 1;
    return bt;
}

/* ----------------------- Tree structure ------------------------ */
struct Q2TreeStruct {
    vector<int> val;
    vector<int> leftIdx;
    vector<int> rightIdx;
    vector<int> parentIdx;
    vector<int> depth;
    map<int,int> valueToIndex; // value -> index
    int rootVal;
    Q2TreeStruct(): rootVal(-1) {}
};

static Q2TreeStruct buildTreeStructure(const vector<int>& preorder,
                                       const vector<int>& inorder) {
    Q2TreeStruct ts;
    size_t N = preorder.size();
    if (N == 0) return ts;
    ts.val = preorder;
    ts.leftIdx.assign(N, -1);
    ts.rightIdx.assign(N, -1);
    ts.parentIdx.assign(N, -1);
    ts.depth.assign(N, 0);

    for (size_t i=0;i<N;++i)
        ts.valueToIndex.insert(make_pair(preorder[i], (int)i));

    ts.rootVal = preorder[0];

    stack<int> st;
    st.push(preorder[0]);
    int inPos = 0;

    for (size_t i=1;i<N;++i) {
        int curVal = preorder[i];
        int topVal = st.top();
        if (topVal != inorder[inPos]) {
            int pIdx = ts.valueToIndex[topVal];
            int cIdx = ts.valueToIndex[curVal];
            ts.leftIdx[pIdx] = cIdx;
            ts.parentIdx[cIdx] = pIdx;
            ts.depth[cIdx] = ts.depth[pIdx] + 1;
            st.push(curVal);
        } else {
            int lastPopped = -1;
            while (!st.empty() && st.top() == inorder[inPos]) {
                lastPopped = st.top();
                st.pop();
                ++inPos;
            }
            int pIdx = ts.valueToIndex[lastPopped];
            int cIdx = ts.valueToIndex[curVal];
            ts.rightIdx[pIdx] = cIdx;
            ts.parentIdx[cIdx] = pIdx;
            ts.depth[cIdx] = ts.depth[pIdx] + 1;
            st.push(curVal);
        }
    }
    return ts;
}

static vector<int> bfsLeafOrder(const Q2TreeStruct& ts) {
    vector<int> leaves;
    if (ts.rootVal == -1) return leaves;
    queue<int> q;
    int rootIdx = ts.valueToIndex.find(ts.rootVal)->second;
    q.push(rootIdx);
    while(!q.empty()) {
        int idx = q.front(); q.pop();
        int L = ts.leftIdx[idx];
        int R = ts.rightIdx[idx];
        if (L == -1 && R == -1) {
            leaves.push_back(ts.val[idx]);
        } else {
            if (L != -1) q.push(L);
            if (R != -1) q.push(R);
        }
    }
    return leaves;
}

static int lca_idx(int aIdx, int bIdx,
                   const vector<int>& parentIdx,
                   const vector<int>& depth) {
    if (aIdx == -1) return bIdx;
    if (bIdx == -1) return aIdx;
    while (depth[aIdx] > depth[bIdx]) aIdx = parentIdx[aIdx];
    while (depth[bIdx] > depth[aIdx]) bIdx = parentIdx[bIdx];
    while (aIdx != bIdx) {
        aIdx = parentIdx[aIdx];
        bIdx = parentIdx[bIdx];
    }
    return aIdx;
}

/* ---------------- Query processing: materialized ---------------- */
vector<int> process_queries_materialized(
    const vector<int>& preorder,
    const vector<int>& inorder,
    const vector< vector<int> >& leafParcels,
    const vector< vector<int> >& queries,
    vector<long long>& runtimes_micro
) {
    Q2TreeStruct ts = buildTreeStructure(preorder, inorder);
    runtimes_micro.assign(queries.size(), 0);
    if (ts.rootVal == -1)
        return vector<int>(queries.size(), -1);

    vector<int> leafOrderVals = bfsLeafOrder(ts);
    size_t L = leafOrderVals.size();
    if (leafParcels.size() < L) L = leafParcels.size();

    map<int,int> parcelToLeafIdx;
    for (size_t i=0;i<L;++i) {
        int leafVal = leafOrderVals[i];
        int leafIdx = ts.valueToIndex.find(leafVal)->second;
        const vector<int>& pv = leafParcels[i];
        for (size_t j=0;j<pv.size();++j)
            parcelToLeafIdx[pv[j]] = leafIdx;
    }

    vector<int> answers;
    answers.reserve(queries.size());
    const vector<int>& parentIdx = ts.parentIdx;
    const vector<int>& depth = ts.depth;

    for (size_t qi=0; qi<queries.size(); ++qi) {
        clock_t cstart = clock();
        const vector<int>& Q = queries[qi];
        if (Q.empty()) {
            answers.push_back(-1);
            continue;
        }
        vector<int> leafIdxs;
        leafIdxs.reserve(Q.size());
        bool miss = false;
        for (size_t j=0;j<Q.size();++j) {
            map<int,int>::iterator it = parcelToLeafIdx.find(Q[j]);
            if (it == parcelToLeafIdx.end()) { miss = true; break; }
            leafIdxs.push_back(it->second);
        }
        int ansVal = -1;
        if (!miss && !leafIdxs.empty()) {
            int ancIdx = leafIdxs[0];
            for (size_t j=1;j<leafIdxs.size(); ++j) {
                ancIdx = lca_idx(ancIdx, leafIdxs[j], parentIdx, depth);
                if (ancIdx == -1) break;
            }
            if (ancIdx != -1) ansVal = ts.val[ancIdx];
        }
        clock_t cend = clock();
        runtimes_micro[qi] =
            (long long)((cend - cstart) * 1000000.0 / CLOCKS_PER_SEC);
        answers.push_back(ansVal);
    }
    return answers;
}

/* ---------------- Query processing: lazy parcels ---------------- */
vector<int> process_queries_lazy(
    const vector<int>& preorder,
    const vector<int>& inorder,
    int leafCount,
    int m,
    long long baseParcel,
    const vector< vector<int> >& queries,
    vector<long long>& runtimes_micro
) {
    Q2TreeStruct ts = buildTreeStructure(preorder, inorder);
    runtimes_micro.assign(queries.size(),0);
    if (ts.rootVal == -1)
        return vector<int>(queries.size(), -1);

    vector<int> leafOrderVals = bfsLeafOrder(ts);
    if ((int)leafOrderVals.size() != leafCount)
        leafCount = (int)leafOrderVals.size();

    vector<int> leafValToIdx;
    leafValToIdx.reserve(leafOrderVals.size());
    for (size_t i=0;i<leafOrderVals.size();++i)
        leafValToIdx.push_back(ts.valueToIndex.find(leafOrderVals[i])->second);

    const vector<int>& parentIdx = ts.parentIdx;
    const vector<int>& depth = ts.depth;

    vector<int> answers;
    answers.reserve(queries.size());

    for (size_t qi=0; qi<queries.size(); ++qi) {
        clock_t cstart = clock();
        const vector<int>& Q = queries[qi];
        if (Q.empty()) {
            answers.push_back(-1);
            continue;
        }
        vector<int> leafIdxs;
        leafIdxs.reserve(Q.size());
        bool invalid=false;
        for (size_t j=0;j<Q.size();++j) {
            long long offset = (long long)Q[j] - baseParcel;
            if (offset < 0) { invalid=true; break; }
            long long leafIdx = offset / m;
            if (leafIdx < 0 || leafIdx >= (long long)leafValToIdx.size()) {
                invalid=true; break;
            }
            leafIdxs.push_back(leafValToIdx[(size_t)leafIdx]);
        }
        int ansVal = -1;
        if (!invalid && !leafIdxs.empty()) {
            int ancIdx = leafIdxs[0];
            for (size_t j=1;j<leafIdxs.size(); ++j) {
                ancIdx = lca_idx(ancIdx, leafIdxs[j], parentIdx, depth);
                if (ancIdx == -1) break;
            }
            if (ancIdx != -1) ansVal = ts.val[ancIdx];
        }
        clock_t cend = clock();
        runtimes_micro[qi] =
            (long long)((cend - cstart) * 1000000.0 / CLOCKS_PER_SEC);
        answers.push_back(ansVal);
    }
    return answers;
}

/* ---------------- Verification (sampled) ---------------- */
bool verify_one_materialized(
    const vector<int>& preorder,
    const vector<int>& inorder,
    const vector< vector<int> >& leafParcels,
    const vector<int>& query,
    int answer)
{
    Q2TreeStruct ts = buildTreeStructure(preorder, inorder);
    if (ts.rootVal == -1) return answer == -1;
    vector<int> leaves = bfsLeafOrder(ts);
    size_t L = leaves.size();
    if (leafParcels.size() < L) L = leafParcels.size();

    map<int,int> parcelToIdx;
    for (size_t i=0;i<L;++i) {
        int val = leaves[i];
        int idx = ts.valueToIndex.find(val)->second;
        const vector<int>& pv = leafParcels[i];
        for (size_t j=0;j<pv.size();++j)
            parcelToIdx[pv[j]] = idx;
    }

    vector<int> idxs;
    idxs.reserve(query.size());
    for (size_t i=0;i<query.size();++i) {
        map<int,int>::iterator it = parcelToIdx.find(query[i]);
        if (it == parcelToIdx.end()) return answer == -1;
        idxs.push_back(it->second);
    }
    if (idxs.empty()) return (answer == -1);

    int anc = idxs[0];
    for (size_t i=1;i<idxs.size();++i)
        anc = lca_idx(anc, idxs[i], ts.parentIdx, ts.depth);
    int ancVal = ts.val[anc];
    return ancVal == answer;
}

/* --------------- Memory estimation (approx) ---------------- */
static size_t bytes_int_vectors_flat(const vector< vector<int> >& vv) {
    size_t total=0;
    for (size_t i=0;i<vv.size();++i)
        total += vv[i].capacity()*sizeof(int);
    return total;
}
static size_t bytes_queries(const vector< vector<int> >& qs) {
    return bytes_int_vectors_flat(qs);
}

/* --------------- Helpers --------------- */
static int iround(double x) { return (int)(x + 0.5); }

/* -------------------------------- MAIN -------------------------------- */
int main() {
    signal(SIGINT, handle_sigint);
    srand(42);

    // ...existing code...

/* ====== TUNABLE CONSTANTS (ADJUSTED FOR 30 TESTS WITHOUT OOM) ====== */
/* Original max values forced huge allocations early (n*m, pool, leafParcels).
   Changes:
   - Use LAZY_MODE = true (no leafParcels/pool materialization).
   - Slow growth of n,k,m via SHAPE_* > 1 so large sizes appear only near the end.
   - Lower PARCEL_CAP (kept only for safety if you switch back to materialized).
*/
const int    NUM_TESTS = 30;
const int    MIN_N = 10;
const int    MAX_N = 1000000;   // keep theoretical max
const int    MIN_M = 1;
const int    MAX_M = 100;
const int    MIN_K = 10;
const int    MAX_K = 100000;
const int    MIN_QSZ = 2;
const int    MAX_QSZ = 100;
const int    MIN_MC = 1;
const int    MAX_MC = 100;

/* Shapes > 1 delay large sizes until later tests (was 0.22 before -> aggressive early growth) */
const double SHAPE_N = 2.0;
const double SHAPE_K = 2.0;
const double SHAPE_M = 2.0;

const long long PARCEL_CAP = 5000000LL;  // lower safety cap

/* CRITICAL: enable lazy mode to avoid allocating n*m parcel arrays */
const bool VERIFY_ALL   = false;
const int  SAMPLE_VERIFY= 5;
const bool LAZY_MODE    = true;

// ...existing code...

    for (int t=1; t<=NUM_TESTS; ++t) {
        double frac = (double)(t-1)/(double)(NUM_TESTS-1);

        // Delayed growth
        double fn = pow(frac, SHAPE_N);
        int n = iround(pow(10.0,
                  log10((double)MIN_N) +
                  (log10((double)MAX_N) - log10((double)MIN_N))*fn));
        if (n < MIN_N) n = MIN_N;
        if (n > MAX_N) n = MAX_N;

        double fk = pow(frac, SHAPE_K);
        int k = iround(pow(10.0,
                  log10((double)MIN_K) +
                  (log10((double)MAX_K) - log10((double)MIN_K))*fk));
        if (k < MIN_K) k = MIN_K;
        if (k > MAX_K) k = MAX_K;

        double fm = pow(frac, SHAPE_M);
        int m = iround(MIN_M + (MAX_M - MIN_M)*fm);
        if (m < MIN_M) m = MIN_M;
        if (m > MAX_M) m = MAX_M;

        // (Optional) clamp early tests harder to ensure speed
        if (t <= 10) {
            if (n > 20000) n = 20000;
            if (k > 5000)  k = 5000;
        } else if (t <= 20) {
            if (n > 200000) n = 200000;
            if (k > 30000)  k = 30000;
        }

        int metro_cities = iround(MIN_MC + (MAX_MC - MIN_MC)*frac);
        if (metro_cities > n) metro_cities = n;

        long long desired = (long long)n * (long long)m;
        if (!LAZY_MODE && desired > PARCEL_CAP) {
            m = (int)(PARCEL_CAP / (long long)max(1,n));
            if (m < 1) m = 1;
        }

        BuiltTree bt = build_balanced_full_tree(n);
        const vector<int>& preorder = bt.preorder;
        const vector<int>& inorder  = bt.inorder;
        int tree_size = bt.total_nodes;

        long long base = 1000000LL * t;

        vector< vector<int> > leafParcels; // unused in lazy mode
        vector< vector<int> > queries;
        queries.reserve(k);

        // LAZY: generate parcel ids arithmetically (no pool / leafParcels)
        for (int qi=0; qi<k; ++qi) {
            int qsz = MIN_QSZ + (rand() % (MAX_QSZ - MIN_QSZ + 1));
            vector<int> qv;
            qv.reserve(qsz);
            for (int j=0;j<qsz;++j) {
                int leafIdx = rand() % n;
                int slot    = rand() % m;
                int parcel_id = (int)(base + (long long)leafIdx * m + slot);
                qv.push_back(parcel_id);
            }
            queries.push_back(qv);
        }

        vector<long long> runtimes_micro;
        vector<int> answers = LAZY_MODE
            ? process_queries_lazy(preorder,inorder,n,m,base,queries,runtimes_micro)
            : process_queries_materialized(preorder,inorder,leafParcels,queries,runtimes_micro);

        long long sum_us = 0;
        for (size_t i=0;i<runtimes_micro.size();++i) sum_us += runtimes_micro[i];
        double sum_ms = sum_us / 1000.0;
        double avg_ms = (k>0)? (sum_ms / k) : 0.0;

        size_t verify_count = (!LAZY_MODE)
            ? ( VERIFY_ALL ? queries.size()
                           : ( queries.size() < (size_t)SAMPLE_VERIFY
                               ? queries.size()
                               : (size_t)SAMPLE_VERIFY ) )
            : 0;

        vector<char> correct(queries.size(), 1);
        if (!LAZY_MODE && verify_count) {
            for (size_t i=0;i<verify_count;++i) {
                if (!verify_one_materialized(preorder,inorder,leafParcels,queries[i],answers[i]))
                    correct[i]=0;
            }
        }

        size_t mem_bytes = 0;
        mem_bytes += preorder.capacity()*sizeof(int);
        mem_bytes += inorder.capacity()*sizeof(int);
        if (!LAZY_MODE) {
            mem_bytes += bytes_int_vectors_flat(leafParcels);
        }
        mem_bytes += bytes_queries(queries);

        for (size_t i=0;i<queries.size();++i) {
            double runtime_ms = runtimes_micro[i] / 1000.0;
            g_fout << t << ','
                   << (i+1) << ','
                   << queries[i].size() << ','
                   << fixed << setprecision(3) << runtime_ms << ','
                   << tree_size << ','
                   << n << ','
                   << k << ','
                   << (correct[i] ? "YES" : "NO") << ','
                   << metro_cities << ',';
            if (i==0) {
                g_fout << fixed << setprecision(3) << sum_ms << ','
                       << fixed << setprecision(3) << avg_ms << ','
                       << mem_bytes;
            } else {
                g_fout << ",,";
            }
            g_fout << '\n';
        }
        g_fout.flush();

        cout << "Test " << setw(2) << t
             << " n=" << n
             << " m=" << m
             << " k=" << k
             << " nodes=" << tree_size
             << " sum_ms=" << fixed << setprecision(3) << sum_ms
             << " mem~" << (mem_bytes/1000000.0) << "MB"
             << (LAZY_MODE ? " [LAZY]" : "")
             << endl;

        // Explicit reclamation (helps fragmentation over many tests)
        vector< vector<int> >().swap(queries);
        vector< vector<int> >().swap(leafParcels);
    }
}
// ...existing code...
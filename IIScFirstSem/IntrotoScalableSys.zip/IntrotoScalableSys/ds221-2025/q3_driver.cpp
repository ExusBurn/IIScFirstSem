// C++98 compatible version (removed: <bits/stdc++.h>, <random>, <chrono>, <atomic>, range-for, auto, structured bindings, initializer_lists)
// Timing via clock(), RNG via rand()/srand(). Priority queues & loops rewritten.

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <csignal>
#include <stack>
#include <ctime>
#include <cstdlib>
#include <fstream>
using namespace std;

/*
CSV Columns:
Test#,Runtime(ms),Nodes,Edges,MetroCount,Result(MeetTime),Connected,Memory(bytes),Verification
*/

static ofstream g_fout;
static bool g_open = false;

void handle_sigint(int){
    if (g_open) {
        g_fout.flush();
        cerr << "\nSIGINT: flushed outputs_q3.csv\n";
    }
    exit(0);
}

// ---------------- Original meeting time implementation (multi-source Dijkstra) -------------
long long question_three(const vector< vector<int> >& edges,
                         const vector<int>& metro_cities) {
    int maxNode = 0;
    for (size_t i=0;i<edges.size();++i) {
        const vector<int>& e = edges[i];
        if (e.size() >= 3) {
            if (e[0] > maxNode) maxNode = e[0];
            if (e[1] > maxNode) maxNode = e[1];
        }
    }
    if ((int)metro_cities.size() < 2) return -1;
    int n = maxNode;

    vector< vector< pair<int,int> > > adj(n+1);
    for (size_t i=0;i<edges.size();++i) {
        const vector<int>& e = edges[i];
        if (e.size() < 3) continue;
        int u = e[0], v = e[1], w = e[2];
        adj[u].push_back(pair<int,int>(v,w));
        adj[v].push_back(pair<int,int>(u,w));
    }

    const long long INF = (long long)4000000000000000000LL;
    vector<long long> dist(n+1, INF);
    vector<int> owner(n+1, -1);

    typedef pair<long long,int> State;
    struct Cmp {
        bool operator()(const State& a, const State& b) const {
            return a.first > b.first;
        }
    };
    priority_queue<State, vector<State>, Cmp> pq;

    for (size_t i=0;i<metro_cities.size();++i) {
        int src = metro_cities[i];
        if (src < 1 || src > n) continue;
        dist[src] = 0;
        owner[src] = src;
        pq.push(State(0, src));
    }

    long long best = INF;

    while (!pq.empty()) {
        State cur = pq.top(); pq.pop();
        long long d = cur.first;
        int u = cur.second;
        if (d != dist[u]) continue;
        if (d > best) break;
        const vector< pair<int,int> >& nei = adj[u];
        for (size_t i=0;i<nei.size();++i) {
            int v = nei[i].first;
            int w = nei[i].second;
            long long nd = d + w;
            if (owner[v] == -1) {
                if (nd < dist[v]) {
                    dist[v] = nd;
                    owner[v] = owner[u];
                    pq.push(State(nd, v));
                }
            } else if (owner[v] != owner[u]) {
                long long sum = dist[u] + dist[v] + w;
                long long meet = sum / 2 + ( (sum & 1) ? 1 : 0 ); // ceil
                if (meet < best) best = meet;
            }
            if (owner[v] == owner[u] && nd < dist[v]) {
                dist[v] = nd;
                pq.push(State(nd, v));
            }
        }
    }
    return (best == INF) ? -1 : best;
}

// ---------------- Independent verification implementation -------------------
long long compute_meeting_time_check(const vector< vector<int> >& edges,
                                     const vector<int>& metro_cities) {
    int maxNode = 0;
    for (size_t i=0;i<edges.size();++i) {
        const vector<int>& e = edges[i];
        if (e.size() >= 3) {
            if (e[0] > maxNode) maxNode = e[0];
            if (e[1] > maxNode) maxNode = e[1];
        }
    }
    if ((int)metro_cities.size() < 2) return -1;
    int n = maxNode;

    vector< vector< pair<int,int> > > adj(n+1);
    for (size_t i=0;i<edges.size();++i) {
        const vector<int>& e = edges[i];
        if (e.size() < 3) continue;
        int u = e[0], v = e[1], w = e[2];
        adj[u].push_back(pair<int,int>(v,w));
        adj[v].push_back(pair<int,int>(u,w));
    }

    const long long INF = (long long)4000000000000000000LL;
    vector<long long> dist(n+1, INF);
    vector<int> owner(n+1, -1);

    typedef pair<long long,int> State;
    struct Cmp {
        bool operator()(const State& a, const State& b) const {
            return a.first > b.first;
        }
    };
    priority_queue<State, vector<State>, Cmp> pq;

    for (size_t i=0;i<metro_cities.size();++i) {
        int s = metro_cities[i];
        if (s < 1 || s > n) continue;
        dist[s] = 0;
        owner[s] = s;
        pq.push(State(0,s));
    }

    long long best = INF;

    while (!pq.empty()) {
        State cur = pq.top(); pq.pop();
        long long d = cur.first;
        int u = cur.second;
        if (d != dist[u]) continue;
        if (d > best) break;
        const vector< pair<int,int> >& nei = adj[u];
        for (size_t i=0;i<nei.size();++i) {
            int v = nei[i].first;
            int w = nei[i].second;
            long long nd = d + w;
            if (owner[v] == -1) {
                if (nd < dist[v]) {
                    dist[v] = nd;
                    owner[v] = owner[u];
                    pq.push(State(nd,v));
                }
            } else if (owner[v] != owner[u]) {
                long long sum = dist[u] + dist[v] + w;
                long long meet = sum / 2 + ( (sum & 1) ? 1 : 0 );
                if (meet < best) best = meet;
            }
            if (owner[v] == owner[u] && nd < dist[v]) {
                dist[v] = nd;
                pq.push(State(nd,v));
            }
        }
    }
    return (best == INF) ? -1 : best;
}

// Approx memory for payload ints
static size_t estimate_memory_bytes(const vector< vector<int> >& edges,
                                    const vector<int>& metros) {
    size_t mem = 0;
    mem += edges.capacity() * sizeof(vector<int>);
    for (size_t i=0;i<edges.size();++i)
        mem += edges[i].capacity() * sizeof(int);
    mem += metros.capacity() * sizeof(int);
    return mem;
}

// Fisher-Yates shuffle (C++98)
static void shuffle_vec(vector<int>& a) {
    for (int i=(int)a.size()-1; i>0; --i) {
        int j = rand() % (i+1);
        int tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
}

// Rounded linear mapping for n
static int round_to_int(double x) {
    if (x >= 0) return (int)(x + 0.5);
    return (int)(x - 0.5);
}

int main() {
    signal(SIGINT, handle_sigint);
    srand(42);

    const int NUM_TESTS = 100;     // adjust if needed (e.g. 30)
    const int MIN_N = 20;
    const int MAX_N = 200000;
    const double SHAPE_N = 0.35;

    const double EDGE_MULT_MIN = 1.2;
    const double EDGE_MULT_MAX = 6.0;
    const double METRO_FRAC_MIN = 0.05;
    const double METRO_FRAC_MAX = 0.30;

    const int MIN_WEIGHT = 2;
    const int MAX_WEIGHT = 200;

    g_fout.open("outputs_q3.csv", ios::out | ios::trunc);
    if (!g_fout) {
        cerr << "Cannot open outputs_q3.csv\n";
        return 1;
    }
    g_open = true;
    g_fout << "Test#,Runtime(ms),Nodes,Edges,MetroCount,Result(MeetTime),Connected,Memory(bytes),Verification\n";
    g_fout.flush();

    double log_min_n = log10((double)MIN_N);
    double log_max_n = log10((double)MAX_N);

    for (int t = 1; t <= NUM_TESTS; ++t) {
        double frac = (double)(t - 1) / (double)(NUM_TESTS - 1);
        double fn = pow(frac, SHAPE_N);
        int n = round_to_int(pow(10.0, log_min_n + (log_max_n - log_min_n)*fn));
        if (n < MIN_N) n = MIN_N;
        if (n > MAX_N) n = MAX_N;

        double edgeMult = EDGE_MULT_MIN + (EDGE_MULT_MAX - EDGE_MULT_MIN) * frac;
        long long targetEdges = (long long)round_to_int(edgeMult * n);
        long long maxPossible = (long long)n * (long long)(n - 1) / 2;
        if (targetEdges > maxPossible) targetEdges = maxPossible;

        double metroFrac = METRO_FRAC_MIN + (METRO_FRAC_MAX - METRO_FRAC_MIN) * frac;
        int metroCount = round_to_int(metroFrac * n);
        if (metroCount < 1) metroCount = 1;
        if (metroCount > n) metroCount = n;

        vector< vector<int> > edges;
        edges.reserve((size_t)targetEdges + 5);

        // Build connected chain first
        for (int i = 1; i < n; ++i) {
            // even weight within bounds
            int rangeHalf = (MAX_WEIGHT - MIN_WEIGHT)/2;
            if (rangeHalf < 0) rangeHalf = 0;
            int w = MIN_WEIGHT + (rand() % (rangeHalf + 1)) * 2;
            vector<int> e; e.push_back(i); e.push_back(i+1); e.push_back(w);
            edges.push_back(e);
        }

        // More random edges (no duplicate avoidance for simplicity)
        while ((long long)edges.size() < targetEdges) {
            int u = (rand() % n) + 1;
            int v = (rand() % n) + 1;
            if (u == v) continue;
            if (u > v) { int tmp=u; u=v; v=tmp; }
            int rangeHalf = (MAX_WEIGHT - MIN_WEIGHT)/2;
            if (rangeHalf < 0) rangeHalf = 0;
            int w = MIN_WEIGHT + (rand() % (rangeHalf + 1)) * 2;
            vector<int> e; e.push_back(u); e.push_back(v); e.push_back(w);
            edges.push_back(e);
        }

        // Nodes 1..n
        vector<int> nodes;
        nodes.reserve(n);
        for (int i=1;i<=n;++i) nodes.push_back(i);
        shuffle_vec(nodes);

        vector<int> metro_cities;
        metro_cities.reserve(metroCount);
        for (int i=0;i<metroCount;++i) metro_cities.push_back(nodes[i]);
        sort(metro_cities.begin(), metro_cities.end());

        size_t mem_bytes = estimate_memory_bytes(edges, metro_cities);

        clock_t cstart = clock();
        long long res = question_three(edges, metro_cities);
        clock_t cend = clock();
        long long us = (long long)((cend - cstart) * 1000000.0 / CLOCKS_PER_SEC);
        double ms = us / 1000.0;

        bool connected = (res != -1);

        long long ref_res = compute_meeting_time_check(edges, metro_cities);
        bool ok = (res == ref_res);

        g_fout << t << ','
               << fixed << setprecision(3) << ms << ','
               << n << ','
               << edges.size() << ','
               << metro_cities.size() << ','
               << res << ','
               << (connected ? "YES" : "NO") << ','
               << mem_bytes << ','
               << (ok ? "YES" : "NO") << '\n';
        g_fout.flush();

        cout << "Test " << setw(3) << t
             << " n=" << n
             << " E=" << edges.size()
             << " metros=" << metro_cities.size()
             << " res=" << res
             << " ref=" << ref_res
             << " ok=" << (ok?"Y":"N")
             << " time(ms)=" << fixed << setprecision(3) << ms
             << " mem~" << (mem_bytes/1000000.0) << "MB"
             << endl;
    }

    g_fout.close();
    g_open = false;
    cout << "All tests complete. Results written to outputs_q3.csv\n";
    return 0;
}
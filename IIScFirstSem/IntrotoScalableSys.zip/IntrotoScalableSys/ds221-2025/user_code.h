#ifndef USER_CODE_H
#define USER_CODE_H

// Feel free to include more library functions
#include <vector>
#include <string>
#include <utility>
#include <iostream>
#include <algorithm>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <array>
#include <limits>
#include <tuple>
#include <stack>
#include <functional> // for greater
using namespace std;


/* 
Complete this function
*/
/*
All Prompts for Q1: If I copied code also into the prompt, first there is code THEN there is some text wanting something changed:

So, I already wrote the three questions using another chat window, but I accidentally deleted that chat window. Is there any way to retrieve it? I presssed the X button.

Okay, alright no problem, I will just use this chat itself and write the code from scratch again.

Alright, I just deleted the code for Q1. Lets first obtain the hashmap id -> (count,min_weight).

Nonono, not like this. Just give me the code on the chat only, I will copy paste it onto vscode. First let's just obtain the hashmap of ID : (Occurence,Min_Weight)

vector<vector<int>> question_one(const vector<vector<int>>& parcels) {
    unordered_map<int, pair<int,int>> mp;
    mp.reserve(parcels.size() * 2);

    for (const auto& row : parcels) {
        if (row.size() < 2) continue; // skip malformed
        int id = row[0];
        int w  = row[1];
        auto it = mp.find(id);
        if (it == mp.end()) {
            mp.emplace(id, make_pair(1, w));
        } else {
            it->second.first += 1;              // increment occurrence
            if (w < it->second.second) it->second.second = w; // update min weight
        }
    }
This is what I have right now. Now, after obtaining the hashmap, Whenever the occurence is >1, I want to push_back the min weight value into an array and return that array.

Can you incorporate this into the original code for me? so that I can just copy paste the entire thing?

Just like the optimisation in Q2, can you do the same for Q1 also?
*/

struct Q1Entry {
    int cnt;
    int minw;
};

static vector<vector<int>> question_one_hash(const vector<vector<int>>& parcels) {
    unordered_map<int,Q1Entry> mp;
    mp.reserve(parcels.size() * 2);

    for (const auto& row : parcels) {
        if (row.size() < 2) continue;
        int id = row[0];
        int w  = row[1];
        auto it = mp.find(id);
        if (it == mp.end()) {
            mp.emplace(id, Q1Entry{1, w});
        } else {
            Q1Entry &e = it->second;
            ++e.cnt;
            if (w < e.minw) e.minw = w;
        }
    }

    vector<vector<int>> out;
    out.reserve(mp.size());
    for (const auto& kv : mp)
        if (kv.second.cnt > 1)
            out.push_back({kv.first, kv.second.minw});

    sort(out.begin(), out.end(), [](const vector<int>& a, const vector<int>& b){
        return a[0] < b[0];
    });
    return out;
}

// Optional low‑memory variant (sorts all rows by id; O(N log N) time, O(1) extra besides output).
static vector<vector<int>> question_one_sort(const vector<vector<int>>& parcels) {
    vector<pair<int,int>> a;
    a.reserve(parcels.size());
    for (const auto& row : parcels)
        if (row.size() >= 2)
            a.emplace_back(row[0], row[1]);

    if (a.empty()) return {};

    sort(a.begin(), a.end(), [](const auto& x, const auto& y){
        return x.first < y.first;
    });

    vector<vector<int>> out;
    int i = 0, n = (int)a.size();
    while (i < n) {
        int id = a[i].first;
        int cnt = 0;
        int mn = a[i].second;
        int j = i;
        while (j < n && a[j].first == id) {
            ++cnt;
            if (a[j].second < mn) mn = a[j].second;
            ++j;
        }
        if (cnt > 1) out.push_back({id, mn});
        i = j;
    }
    return out;
}

// Dispatcher: choose hash (default) or sorted path via macro.
vector<vector<int>> question_one(const vector<vector<int>>& parcels) {
#ifdef Q1_USE_SORT_PATH
    return question_one_sort(parcels);
#else
    return question_one_hash(parcels);
#endif
}

/*
Q1 Summary (Improved):

Goal:
Given parcels as rows [id, weight], output all IDs that appear more than once,
paired with the minimum weight among their occurrences: [id, min_weight], sorted by id.

Hash-Map Approach (default):
1. Single pass: unordered_map<int, {count, min_weight}>.
2. Collect entries with count > 1 into result vector.
3. Sort result by id (ascending).

Time Complexity:
- Build map: O(N)
- Collect + filter: O(M) where M = number of unique IDs
- Sort output: O(D log D) where D = number of duplicate IDs returned
Worst case (all IDs duplicated): D = M ≈ N → O(N log N). Typical: O(N).

Space Complexity:
- O(M) for hash map
- O(D) for output
Total O(M + D) ≤ O(N).

Optional Sort-Based Variant (Q1_USE_SORT_PATH):
- Copy (id, weight) pairs then sort by id: O(N log N)
- Single linear scan to compute counts + mins: O(N)
- No hash map; lower peak memory if id universe is huge or hash overhead matters.

Scalability:
- Hash path preferred when N large and duplicates moderate (amortized O(1) insert/find).
- Sort path predictable and may outperform if hash contention or memory constraints arise.

Edge Cases:
- Empty input → empty output
- All unique IDs → empty output
- Negative or zero weights handled naturally
- Malformed rows (<2 elements) ignored

Determinism:
- Output strictly sorted by id (stable ordering)







/* 
Complete this function
*/
struct Q2TreeStruct {
    vector<int> val;            // index -> original node value
    vector<int> leftIdx;        // index -> left child index or -1
    vector<int> rightIdx;       // index -> right child index or -1
    vector<int> parentIdx;      // index -> parent index or -1
    vector<int> depth;          // index -> depth
    unordered_map<int,int> valueToIndex; // node value -> index
    int rootVal = -1;
};

// Build structure iteratively (no recursion)
static Q2TreeStruct buildTreeStructure(const vector<int>& preorder,
                                       const vector<int>& inorder) {
    Q2TreeStruct ts;
    size_t N = preorder.size();
    if (N == 0) return ts;

    ts.val = preorder;
    ts.leftIdx.assign(N, -1);
    ts.rightIdx.assign(N, -1);
    ts.parentIdx.assign(N, -1);
    ts.depth.assign(N, 0);
    ts.valueToIndex.reserve(N * 2);

    for (size_t i = 0; i < N; ++i)
        ts.valueToIndex[preorder[i]] = (int)i;

    ts.rootVal = preorder[0];

    stack<int> st; // node values
    st.push(preorder[0]);
    int inorderPos = 0;

    for (size_t i = 1; i < N; ++i) {
        int curVal = preorder[i];
        int topVal = st.top();
        if (topVal != inorder[inorderPos]) {
            int pIdx = ts.valueToIndex[topVal];
            int cIdx = ts.valueToIndex[curVal];
            ts.leftIdx[pIdx] = cIdx;
            ts.parentIdx[cIdx] = pIdx;
            ts.depth[cIdx] = ts.depth[pIdx] + 1;
            st.push(curVal);
        } else {
            int lastPopped = -1;
            while (!st.empty() && st.top() == inorder[inorderPos]) {
                lastPopped = st.top();
                st.pop();
                ++inorderPos;
            }
            int pIdx = ts.valueToIndex[lastPopped];
            int cIdx = ts.valueToIndex[curVal];
            ts.rightIdx[pIdx] = cIdx;
            ts.parentIdx[cIdx] = pIdx;
            ts.depth[cIdx] = ts.depth[pIdx] + 1;
            st.push(curVal);
        }
    }
    return ts;
}

// BFS to collect leaves (store original values)
static vector<int> bfsLeafOrder(const Q2TreeStruct& ts) {
    vector<int> leaves;
    if (ts.rootVal == -1) return leaves;
    queue<int> q;
    q.push(ts.valueToIndex.at(ts.rootVal));
    while (!q.empty()) {
        int idx = q.front(); q.pop();
        int L = ts.leftIdx[idx];
        int R = ts.rightIdx[idx];
        if (L == -1 && R == -1) {
            leaves.push_back(ts.val[idx]);
        } else {
            if (L != -1) q.push(L);
            if (R != -1) q.push(R);
        }
    }
    return leaves;
}

// LCA (value-based) via parent climb
static int lca_value(int aVal, int bVal, const Q2TreeStruct& ts) {
    if (aVal == -1) return bVal;
    if (bVal == -1) return aVal;
    auto itA = ts.valueToIndex.find(aVal);
    auto itB = ts.valueToIndex.find(bVal);
    if (itA == ts.valueToIndex.end() || itB == ts.valueToIndex.end())
        return -1;
    int a = itA->second;
    int b = itB->second;
    while (ts.depth[a] > ts.depth[b]) a = ts.parentIdx[a];
    while (ts.depth[b] > ts.depth[a]) b = ts.parentIdx[b];
    while (a != b) {
        a = ts.parentIdx[a];
        b = ts.parentIdx[b];
    }
    return ts.val[a];
}


/*
All Prompts for Q2, Leaving 1 line for next prompt. If code is in the prompt, first the code is written then there is some text wanting changes:
Alright, let's do question_two now. I just deleted the code. First, lets construct a tree given preorder and inorder. Then, obtain level order traversal.

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v): val(v), left(nullptr), right(nullptr) {}
};

// Recursive helper
TreeNode* buildTreeRec(const vector<int>& preorder, int preL, int preR,
                       const vector<int>& inorder,  int inL,  int inR,
                       const unordered_map<int,int>& inPos) {
    if (preL > preR || inL > inR) return nullptr;
    int rootVal = preorder[preL];
    int k = inPos.at(rootVal);              // index in inorder
    int leftSize = k - inL;
    TreeNode* root = new TreeNode(rootVal);
    root->left  = buildTreeRec(preorder, preL+1, preL+leftSize,
                               inorder,  inL, k-1, inPos);
    root->right = buildTreeRec(preorder, preL+leftSize+1, preR,
                               inorder,  k+1, inR, inPos);
    return root;
}

TreeNode* buildTree(const vector<int>& preorder,
                    const vector<int>& inorder) {
    if (preorder.empty()) return nullptr;
    unordered_map<int,int> inPos;
    inPos.reserve(inorder.size()*2);
    for (int i = 0; i < (int)inorder.size(); ++i) inPos[inorder[i]] = i;
    return buildTreeRec(preorder, 0, (int)preorder.size()-1,
                        inorder,  0, (int)inorder.size()-1, inPos);
}

// Returns level-order traversal (BFS)
vector<int> levelOrder(TreeNode* root) {
    vector<int> order;
    if (!root) return order;
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty()) {
        TreeNode* cur = q.front(); q.pop();
        order.push_back(cur->val);
        if (cur->left)  q.push(cur->left);
        if (cur->right) q.push(cur->right);
    }
    return order;
}

vector<int> question_two(
    const vector<int>& preorder,
    const vector<int>& inorder,
    const vector<vector<int>>& leafParcels,
    const vector<vector<int>>& query
) {
    
}
This is what I have. I want to obtain the level order array. Now, I want to map the queries to the leaf nodes. Can you do that for me?

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v): val(v), left(nullptr), right(nullptr) {}
};

// Recursive helper
TreeNode* buildTreeRec(const vector<int>& preorder, int preL, int preR,
                       const vector<int>& inorder,  int inL,  int inR,
                       const unordered_map<int,int>& inPos) {
    if (preL > preR || inL > inR) return nullptr;
    int rootVal = preorder[preL];
    int k = inPos.at(rootVal);              // index in inorder
    int leftSize = k - inL;
    TreeNode* root = new TreeNode(rootVal);
    root->left  = buildTreeRec(preorder, preL+1, preL+leftSize,
                               inorder,  inL, k-1, inPos);
    root->right = buildTreeRec(preorder, preL+leftSize+1, preR,
                               inorder,  k+1, inR, inPos);
    return root;
}

TreeNode* buildTree(const vector<int>& preorder,
                    const vector<int>& inorder) {
    if (preorder.empty()) return nullptr;
    unordered_map<int,int> inPos;
    inPos.reserve(inorder.size()*2);
    for (int i = 0; i < (int)inorder.size(); ++i) inPos[inorder[i]] = i;
    return buildTreeRec(preorder, 0, (int)preorder.size()-1,
                        inorder,  0, (int)inorder.size()-1, inPos);
}

// Returns level-order traversal (BFS)
vector<int> levelOrder(TreeNode* root) {
    vector<int> order;
    if (!root) return order;
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty()) {
        TreeNode* cur = q.front(); q.pop();
        order.push_back(cur->val);
        if (cur->left)  q.push(cur->left);
        if (cur->right) q.push(cur->right);
    }
    return order;
}

vector<int> question_two(
    const vector<int>& preorder,
    const vector<int>& inorder,
    const vector<vector<int>>& leafParcels,
    const vector<vector<int>>& query
) {
}
Wait, this is the code that is given. Now, in question_two, I just want you to obtain the level order in array form and print it.

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v): val(v), left(nullptr), right(nullptr) {}
};

// Recursive helper
TreeNode* buildTreeRec(const vector<int>& preorder, int preL, int preR,
                       const vector<int>& inorder,  int inL,  int inR,
                       const unordered_map<int,int>& inPos) {
    if (preL > preR || inL > inR) return nullptr;
    int rootVal = preorder[preL];
    int k = inPos.at(rootVal);              // index in inorder
    int leftSize = k - inL;
    TreeNode* root = new TreeNode(rootVal);
    root->left  = buildTreeRec(preorder, preL+1, preL+leftSize,
                               inorder,  inL, k-1, inPos);
    root->right = buildTreeRec(preorder, preL+leftSize+1, preR,
                               inorder,  k+1, inR, inPos);
    return root;
}

TreeNode* buildTree(const vector<int>& preorder,
                    const vector<int>& inorder) {
    if (preorder.empty()) return nullptr;
    unordered_map<int,int> inPos;
    inPos.reserve(inorder.size()*2);
    for (int i = 0; i < (int)inorder.size(); ++i) inPos[inorder[i]] = i;
    return buildTreeRec(preorder, 0, (int)preorder.size()-1,
                        inorder,  0, (int)inorder.size()-1, inPos);
}

// Returns level-order traversal (BFS)
vector<int> levelOrder(TreeNode* root) {
    vector<int> order;
    if (!root) return order;
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty()) {
        TreeNode* cur = q.front(); q.pop();
        order.push_back(cur->val);
        if (cur->left)  q.push(cur->left);
        if (cur->right) q.push(cur->right);
    }
    return order;
}

vector<int> question_two(
    const vector<int>& preorder,
    const vector<int>& inorder,
    const vector<vector<int>>& leafParcels,
    const vector<vector<int>>& query
) {
    // Build tree
    TreeNode* root = buildTree(preorder, inorder);
    vector<int> level;
    if (!root) return level;

    // BFS level-order
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty()) {
        TreeNode* cur = q.front(); q.pop();
        level.push_back(cur->val);
        if (cur->left)  q.push(cur->left);
        if (cur->right) q.push(cur->right);
    }

    // DEBUG PRINT (remove before submission)
    cout << "Level order:";
    for (int v : level) cout << ' ' << v;
    cout << '\n';

    return level; // for now just return the traversal
}
Alright great. Now, let's map the queries to the leaf nodes, basically the last elements of the arrays with the queries provided. The queries are also from leafParcels.

2 errors, leafNodes is undefined and some error with min also.     size_t L = min(leafNodes.size(), leafParcels.size());

So why is Q0 giving me 3? Shouldn't it give me 3 3? I basically want an array, where every query is mapped to that specific leaf node, and then LCA is found on that array. Can you implement that for me? Then the LCA is stored into an array for each query and that array is returned.

is Q2 well optimised? Or do we have to add the binary lifting logic for it being able to handle big data?

Alright, could you make those changes for me I can copy paste that onto Q2

Can you incorporate this into the original code for me? so that I can just copy paste the entire thing?
*/

vector<int> question_two(
    const vector<int>& preorder,
    const vector<int>& inorder,
    const vector<vector<int>>& leafParcels,
    const vector<vector<int>>& query
) {
    Q2TreeStruct ts = buildTreeStructure(preorder, inorder);
    if (ts.rootVal == -1) return vector<int>(query.size(), -1);

    vector<int> leafNodesBFS = bfsLeafOrder(ts);

    unordered_map<int,int> parcelToLeaf;
    size_t L = min(leafParcels.size(), leafNodesBFS.size());

    size_t totalParcels = 0;
    for (size_t i = 0; i < L; ++i) totalParcels += leafParcels[i].size();
    parcelToLeaf.reserve(totalParcels * 2);

    for (size_t i = 0; i < L; ++i) {
        int leafVal = leafNodesBFS[i];
        for (int parcel : leafParcels[i])
            parcelToLeaf[parcel] = leafVal;
    }

    vector<int> answers;
    answers.reserve(query.size());

    for (const auto& qv : query) {
        if (qv.empty()) { answers.push_back(-1); continue; }
        vector<int> leaves;
        leaves.reserve(qv.size());
        bool missing = false;
        for (int parcel : qv) {
            auto it = parcelToLeaf.find(parcel);
            if (it == parcelToLeaf.end()) { missing = true; break; }
            leaves.push_back(it->second);
        }
        if (missing || leaves.empty()) {
            answers.push_back(-1);
            continue;
        }
        int anc = leaves[0];
        for (size_t i = 1; i < leaves.size(); ++i) {
            anc = lca_value(anc, leaves[i], ts);
            if (anc == -1) break;
        }
        answers.push_back(anc);
    }
    return answers;
}
/*
Q2 Summary (Updated)

Problem:
Reconstruct a binary tree from preorder and inorder traversals (distinct node values).
Each leaf (in BFS / level-order discovery order) is associated with a list of parcel IDs (leafParcels[i]).
Queries: each query is a list of parcel IDs. For every query return the LCA (Lowest Common Ancestor) of all leaves that contain those parcels. If any parcel in a query is unknown (not mapped to a leaf) or the query is empty → return -1.

Data Structures:
- Q2TreeStruct: arrays (val, leftIdx, rightIdx, parentIdx, depth) + valueToIndex map.
- Iterative O(N) reconstruction using preorder + inorder + stack (no recursive TreeNode allocation).
- Leaf discovery via BFS over index-based tree arrays.
- parcelToLeaf: unordered_map<int,int> mapping parcel ID → leaf node value.
- LCA computed by climbing parents with depth alignment (no heavy preprocessing).

Algorithm Steps:
1. Build tree structure (buildTreeStructure):
   Uses preorder traversal stack method, synchronized with inorder pointer to assign left/right children and depths.
2. Collect leaves (bfsLeafOrder) in level-order; order aligns with leafParcels indexing.
3. Map parcels:
   For i in [0, min(leaves, leafParcels) ):
       For each parcel p in leafParcels[i]:
           parcelToLeaf[p] = leafValue[i]
4. Process each query:
   - Translate parcel IDs → corresponding leaf node values (fail if any missing).
   - Fold LCAs: lca = LCA(l1,l2,...,lk) by pairwise reduction using parent climbing.
   - Append lca (or -1 on failure) to answers.
5. Return answers vector.

LCA Method (parent climb):
- Ensure both nodes at same depth (lift deeper one).
- Climb both simultaneously until equal; value at meeting index is result.
- Runs in O(h) per pair; h = tree height.

Complexity:
Let:
  n = number of nodes
  L = number of leaves
  P = total parcels across all leaves
  Q = number of queries
  Ki = size of i-th query
  h = tree height (≈ log n for balanced, worst n for skew)
Time:
  Tree build: O(n)
  Leaf BFS: O(n)
  Parcel mapping: O(P)
  Queries: Σ O(Ki * h)
Total: O(n + P + (Σ Ki) * h)
Space:
  O(n) for arrays + O(P) parcel map + O(Kmax) temporary per query.

/*
Q2 Summary (Updated + Binary Lifting Rationale)

Why Binary Lifting NOT Added:
- Preprocessing Cost: Building jump table needs O(n log n) time and O(n log n) extra memory.
- Query Pattern: Each query’s cost depends on its internal list size (query width), not just number of queries. Current per-query LCA reduction cost is O(K * h) with K = query size (usually small, e.g. <= 10) and h = tree height (log n for balanced, worst n for skew). With small K, parent climbing is already very fast.
- Overhead vs Benefit: For small K, the O(log n) per pair using lifting gives negligible win over simple parent climb, but the upfront O(n log n) preprocessing dominates total runtime.
- Memory Impact: jump[k][v] table roughly n * floor(log2 n) integers; for large n this increases memory footprint and cache pressure.
- Code Complexity: Adds maintenance burden and risk of bugs for marginal or no gain under current expected query shapes.
- When to Add Later: Only justified if (Σ K) * h becomes a bottleneck (e.g. very deep skewed trees or very large K per query), or if queries require ultra-low latency at scale.

Net: Simpler O(n) structure + O(K * h) per query is sufficient and lean for current constraints.
Edge Cases Handled:
- Empty traversals → returns vector of -1s (or empty if no queries).
- Query empty → -1.
- Parcel not found → -1.
- All parcels of a query map to same leaf → returns that leaf value.

Assumptions:
- Distinct node values in traversals.
- leafParcels aligned with BFS leaf order (first leafParcels entry corresponds to first BFS leaf).
- Each parcel belongs to exactly one leaf.

Potential Improvements (Optional):
- Validate leafParcels.size() == leaves.size().
- Add binary lifting if (Σ Ki) large or skewed tree common.
- Compress node values to 0..n-1 earlier to avoid unordered_map in valueToIndex.

Result:
Memory-efficient, iterative, avoids recursion limits, fast enough under typical constraints; extensible if higher query volume or deeper trees arise.
/* 
Complete this function
*/
using EdgeList = vector<vector<int>>; // each edge: {u,v,w}

// 1. Determine n (highest node id)
int findN(const EdgeList& edges) {
    int n = 0;
    for (const auto& e : edges) {
        if (e.size() < 3) continue;
        n = max(n, max(e[0], e[1]));
    }
    return n;
}

// 2. Build adjacency list: graph[u] = { {v,w}, ... }
vector<vector<pair<int,int>>> buildGraph(const EdgeList& edges, int n) {
    vector<vector<pair<int,int>>> g(n+1);
    g.reserve(n+1);
    for (const auto& e : edges) {
        if (e.size() < 3) continue;
        int u = e[0], v = e[1], w = e[2];
        g[u].push_back({v,w});
        g[v].push_back({u,w});
    }
    return g;
}

constexpr long long INF = (std::numeric_limits<long long>::max() / 4);

struct BoosterDijkstraResult {
    std::vector<std::array<long long,2>> dist; // [node][state]
};

BoosterDijkstraResult dijkstraWithBooster(
    int start,
    const std::vector<std::vector<std::pair<int,int>>>& graph,
    const std::vector<char>& isMetro
) {
    int n = (int)graph.size() - 1;
    std::vector<std::array<long long,2>> dist(n+1);
    for (int i = 0; i <= n; ++i) {
        dist[i][0] = INF;
        dist[i][1] = INF;
    }
    dist[start][0] = 0;

    using State = std::tuple<long long,int,int>;
    std::priority_queue<State, std::vector<State>, std::greater<State>> pq;
    pq.push({0, start, 0});

    while (!pq.empty()) {
        auto [d,u,used] = pq.top(); pq.pop();
        if (d != dist[u][used]) continue;

        for (auto [v,w] : graph[u]) {
            // unboosted path
            if (!used) {
                long long nd = d + w;
                if (nd < dist[v][0]) {
                    dist[v][0] = nd;
                    pq.push({nd, v, 0});
                }
                if (isMetro[u]) {
                    long long nd2 = d + (w >> 1); // w/2
                    if (nd2 < dist[v][1]) {
                        dist[v][1] = nd2;
                        pq.push({nd2, v, 1});
                    }
                }
            } else {
                long long nd = d + (w >> 1);
                if (nd < dist[v][1]) {
                    dist[v][1] = nd;
                    pq.push({nd, v, 1});
                }
            }
        }
    }
    return { std::move(dist) };
}


/*
Prompts for Q3: If there is some code, first the code is pasted then some text wanting changes

Alright, let's now do question 3:
A logistics company operates warehouses in several cities across the country. The country’s road map can be represented as a weighted graph:

Each city is a node (numbered 1 to n).
Each road between two cities is an edge, with the weight representing the travel time.
Two trucks start their journeys simultaneously:

One from Kargil (node 1).
One from Kanyakumari (node n).
Among the n cities, k of them are metro cities equipped with booster fuel stations. At these stations:

Refueling takes 0 time.
Once a truck refuels, its speed doubles, meaning the travel time on every subsequent road is reduced to half the original time.
Note that refueling can be done only once by each truck
The drivers of the two trucks are old school friends who wish to meet each other as soon as possible. Since they are meeting after a long time, they want to meet in a city rather than on a road connecting the cities. One can also wait for the other in a city (node). Your task is to determine the earliest possible time at which they can meet, if they both follow optimal routes.

Complete function question_three, and if the two trucks cannot meet due to no connection between Kargil and Kanyakumari (i.e., if nodes 1 and n are disconnected), return -1.

Input
The graph of the country: cities (nodes) and roads (edges with travel times).
A list of cities containing booster fuel stations.
Note: For simplification, all edge weights (travel times) are guaranteed to be even numbers.
Output
The minimum time units after which the two trucks can meet.
Return -1 if no meeting is possible.
Additional Information
The function signature, input format, and output format are described in function_syntax.md.
Example test files for sanity check:
sample_tests/question3/input.txt
sample_tests/question3/output.txt
So, let's start by first analysing the code that already is present for question_three. I wll then delete it and then we wills tart fresh.

Alright. Now, let's first obtain an adjacency list as done previously. After obtaining an adjacency list, I want to find the ending value(n) for running dijkstra from 1 to n and then n to 1.

using EdgeList = vector<vector<int>>; // each edge: {u,v,w}

// 1. Determine n (highest node id)
int findN(const EdgeList& edges) {
    int n = 0;
    for (const auto& e : edges) {
        if (e.size() < 3) continue;
        n = max(n, max(e[0], e[1]));
    }
    return n;
}

// 2. Build adjacency list: graph[u] = { {v,w}, ... }
vector<vector<pair<int,int>>> buildGraph(const EdgeList& edges, int n) {
    vector<vector<pair<int,int>>> g(n+1);
    g.reserve(n+1);
    for (const auto& e : edges) {
        if (e.size() < 3) continue;
        int u = e[0], v = e[1], w = e[2];
        g[u].push_back({v,w});
        g[v].push_back({u,w});
    }
    return g;
}

// 3. Standard single-state Dijkstra (no booster yet)
vector<long long> dijkstraSingle(int start, const vector<vector<pair<int,int>>>& g) {
    const long long INF = numeric_limits<long long>::max()/4;
    int n = (int)g.size() - 1;
    vector<long long> dist(n+1, INF);
    dist[start] = 0;
    using State = pair<long long,int>; // (dist,node)
    priority_queue<State, vector<State>, greater<State>> pq;
    pq.push({0,start});
    while (!pq.empty()) {
        auto [d,u] = pq.top(); pq.pop();
        if (d != dist[u]) continue;
        for (auto [v,w] : g[u]) {
            long long nd = d + w;
            if (nd < dist[v]) {
                dist[v] = nd;
                pq.push({nd,v});
            }
        }
    }
    return dist;
}

long long question_three(
    const vector<vector<int>>& edges,
    const vector<int>& metro_cities
) {
    
}
Alright, can you slowly implement these functions into question_three first before we proceed to modify the dijkstra? Basically, just run dijkstra from 1 to n and then n to 1.

Alright great. Now, let's add the booster logic. When make a hashmap where metrocities are there. In the dijkstra function, when our starting node is a metrocity, the ending node value must have the minimum of(what it already has, starting node + w/2), where w is the weight to go from starting to ending. And now, that this has been done, Put some kind of flag variable that indicates that the booster has been used, and every single movement will perform the same algorithm for calculating the shortest path.

    int n = findN(edges);
    if (n < 2) return -1;

    auto graph = buildGraph(edges, n);

    // Metro lookup O(1)
    vector<char> isMetro(n+1, 0);
    for (int c : metro_cities)
        if (c >= 1 && c <= n) isMetro[c] = 1;

    // Run two-source booster Dijkstra
    auto res1 = dijkstraWithBooster(1, graph, isMetro);
    auto resN = dijkstraWithBooster(n, graph, isMetro);
    return (0 >= 0 ? -1 : 0);
    Alright, now finally just need to modify this return statement, to return the minimum of the (max of ith element) of res1 and resN. I think that's the answer. Is it maximum of the minimum? I don't remember exactly. Can you figure it out for me based on the question statement?

    struct BoosterDijkstraResult {
    // dist[node][state] where state 0=not used, 1=used
    vector<array<long long,2>> dist;
};

BoosterDijkstraResult dijkstraWithBooster(
    int start,
    const vector<vector<pair<int,int>>>& graph,
    const vector<char>& isMetro
) {
    const long long INF = numeric_limits<long long>::max()/4;
    int n = (int)graph.size() - 1;
    vector<array<long long,2>> dist(n+1, {array<long long,2>{INF, INF}});
    dist[start][0] = 0;

    using State = tuple<long long,int,int>; // (dist,node,usedFlag)
    priority_queue<State, vector<State>, greater<State>> pq;
    pq.push({0, start, 0});

    while (!pq.empty()) {
        auto [d,u,used] = pq.top(); pq.pop();
        if (d != dist[u][used]) continue;

        for (auto [v,w] : graph[u]) {
            // Case 1: travel without using booster (if not yet used)
            if (!used) {
                long long nd = d + w;
                if (nd < dist[v][0]) {
                    dist[v][0] = nd;
                    pq.push({nd, v, 0});
                }
                // Case 2: activate booster at u if metro; edge cost becomes w/2
                if (isMetro[u]) {
                    long long nd2 = d + (w/2);
                    if (nd2 < dist[v][1]) {
                        dist[v][1] = nd2;
                        pq.push({nd2, v, 1});
                    }
                }
            } else {
                // Booster already used: every edge costs w/2
                long long nd = d + (w/2);
                if (nd < dist[v][1]) {
                    dist[v][1] = nd;
                    pq.push({nd, v, 1});
                }
            }
        }
    }
    return { std::move(dist) };
}
There seem to be a few errors in this function dijkstrawithbooster. array, INF, dist[start][0], [used], etc. Can you fix them for me?

using EdgeList = vector<vector<int>>; // each edge: {u,v,w}

// 1. Determine n (highest node id)
int findN(const EdgeList& edges) {
    int n = 0;
    for (const auto& e : edges) {
        if (e.size() < 3) continue;
        n = max(n, max(e[0], e[1]));
    }
    return n;
}

// 2. Build adjacency list: graph[u] = { {v,w}, ... }
vector<vector<pair<int,int>>> buildGraph(const EdgeList& edges, int n) {
    vector<vector<pair<int,int>>> g(n+1);
    g.reserve(n+1);
    for (const auto& e : edges) {
        if (e.size() < 3) continue;
        int u = e[0], v = e[1], w = e[2];
        g[u].push_back({v,w});
        g[v].push_back({u,w});
    }
    return g;
}

struct BoosterDijkstraResult {
    // dist[node][state] where state 0=not used, 1=used
    vector<array<long long,2>> dist;
};

BoosterDijkstraResult dijkstraWithBooster(
    int start,
    const vector<vector<pair<int,int>>>& graph,
    const vector<char>& isMetro
) {
    const long long INF = numeric_limits<long long>::max()/4;
    int n = (int)graph.size() - 1;
    vector<array<long long,2>> dist(n+1, {array<long long,2>{INF, INF}});
    dist[start][0] = 0;

    using State = tuple<long long,int,int>; // (dist,node,usedFlag)
    priority_queue<State, vector<State>, greater<State>> pq;
    pq.push({0, start, 0});

    while (!pq.empty()) {
        auto [d,u,used] = pq.top(); pq.pop();
        if (d != dist[u][used]) continue;

        for (auto [v,w] : graph[u]) {
            // Case 1: travel without using booster (if not yet used)
            if (!used) {
                long long nd = d + w;
                if (nd < dist[v][0]) {
                    dist[v][0] = nd;
                    pq.push({nd, v, 0});
                }
                // Case 2: activate booster at u if metro; edge cost becomes w/2
                if (isMetro[u]) {
                    long long nd2 = d + (w/2);
                    if (nd2 < dist[v][1]) {
                        dist[v][1] = nd2;
                        pq.push({nd2, v, 1});
                    }
                }
            } else {
                // Booster already used: every edge costs w/2
                long long nd = d + (w/2);
                if (nd < dist[v][1]) {
                    dist[v][1] = nd;
                    pq.push({nd, v, 1});
                }
            }
        }
    }
    return { std::move(dist) };
}

long long question_three(
    const vector<vector<int>>& edges,
    const vector<int>& metro_cities
) {
    int n = findN(edges);
    if (n < 2) return -1;

    auto graph = buildGraph(edges, n);

    // Metro lookup O(1)
    vector<char> isMetro(n+1, 0);
    for (int c : metro_cities)
        if (c >= 1 && c <= n) isMetro[c] = 1;

    // Run two-source booster Dijkstra
    auto res1 = dijkstraWithBooster(1, graph, isMetro);
    auto resN = dijkstraWithBooster(n, graph, isMetro);
    const long long INF = numeric_limits<long long>::max()/4;

    // Quick connectivity check (optional)
    if (min(res1.dist[n][0], res1.dist[n][1]) >= INF ||
        min(resN.dist[1][0], resN.dist[1][1]) >= INF)
        return -1;

    long long best = INF;
    for (int i = 1; i <= n; ++i) {
        long long t1 = min(res1.dist[i][0], res1.dist[i][1]);
        long long t2 = min(resN.dist[i][0], resN.dist[i][1]);
        if (t1 >= INF || t2 >= INF) continue; // unreachable for one side
        long long meet = max(t1, t2);
        if (meet < best) best = meet;
    }
    return (best >= INF ? -1 : best);
}
Alright, this code seems to be working well. Any modifications you would like to suggest? I could just copy paste that code.

What should I replace this with? The entire code? Or should I keep some functions? like findN, building the list, etc?
*/
long long question_three(
    const std::vector<std::vector<int>>& edges,
    const std::vector<int>& metro_cities
) {
    int n = findN(edges);
    if (n < 2) return -1;

    auto graph = buildGraph(edges, n);

    std::vector<char> isMetro(n+1, 0);
    for (int c : metro_cities)
        if (c >= 1 && c <= n) isMetro[c] = 1;

    auto res1 = dijkstraWithBooster(1, graph, isMetro);
    auto resN = dijkstraWithBooster(n, graph, isMetro);

    if (std::min(res1.dist[n][0], res1.dist[n][1]) >= INF ||
        std::min(resN.dist[1][0], resN.dist[1][1]) >= INF)
        return -1;

    long long best = INF;
    for (int i = 1; i <= n; ++i) {
        long long t1 = std::min(res1.dist[i][0], res1.dist[i][1]);
        long long t2 = std::min(resN.dist[i][0], resN.dist[i][1]);
        if (t1 >= INF || t2 >= INF) continue;
        long long meet = (t1 > t2 ? t1 : t2);
        if (meet < best) {
            best = meet;
            if (best == 0) break; // cannot improve further
        }
    }
    return (best >= INF ? -1 : best);
}

/* Summary for report (Question 3): We have an undirected weighted graph with nodes labeled 1..n. Two trucks start at nodes 1 and n. Each truck may (independently) activate a single “booster” exactly once, but only when standing at a metro city. Once activated, every subsequent edge the truck travels costs half its original weight (integer division w/2). Goal: find the earliest possible meeting time t (minimum over all nodes) such that both trucks can reach the same node by time t (they may wait after arrival). Return -1 if they can’t meet.

Algorithm:

Build adjacency list from edge list.
Mark metro cities in an O(1) lookup array.
Run a modified Dijkstra from source 1 with state = {booster_unused (0), booster_used (1)}:
State (u,0): can move normally (cost +w) and, if u is metro, optionally “activate” booster for that edge (cost +w/2 → state 1).
State (u,1): booster already active; all outgoing edges cost +w/2. Store dist1[u][state].
Run the same two‑state Dijkstra from source n → distN[u][state].
For each meeting node i, compute: t1 = min(dist1[i][0], dist1[i][1]) t2 = min(distN[i][0], distN[i][1]) If both finite, meeting time at i is max(t1, t2) (the later arrival; earlier truck can wait).
Answer = min over i of that max; if none finite, return -1.
Correctness Rationale: Independent booster usage is captured by two-state shortest paths per source. Waiting is free, so the meeting time at a node is governed by the slower arrival. Minimizing over all nodes yields the earliest feasible meeting.

Complexity: Let V = n (largest node id), E = number of edges. Two-state Dijkstra complexity: O(E log V) (just a 2× factor in nodes/states). Total: O(E log V) time, O(V) space for dist arrays per run (2*V states). Overall memory: O(E + V).

Edge Cases:

Disconnected endpoints → immediate -1 (no path one direction).
Graph with only nodes 1 and n.
No metro cities → algorithm reduces to ordinary bidirectional arrival computation (no halving ever used).
Metro at sources → booster can be activated on first move.
Integer division halving: w/2 truncates (consistent with provided implementation).
Assumptions:

Edge list may contain duplicates or be unsorted (handled naturally).
Node labels are positive; n inferred as max endpoint.
Weights are non-negative (Dijkstra precondition).
Large weights won’t overflow 64-bit when summed (using long long and INF guard).
Potential Improvements:

Early pruning: track current global best meeting time while scanning nodes; (already naturally minimal scan).
Bidirectional multi-state search to potentially reduce constant factors.
If input supplies n directly, skip scanning edges to find n.
Return: Minimal earliest meeting time, or -1 if unreachable.

*/

#endif // USER_CODE_H